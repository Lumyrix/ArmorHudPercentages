
package com.notryken;

import net.fabricmc.loader.api.FabricLoader;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.LinearGradientPaint;
import java.awt.geom.RoundRectangle2D;
import java.io.InputStream;
import java.net.URI;
import java.util.Locale;
import java.util.Map;

/**
 * Native Swing dialog shown when LumLib is missing.
 * Call LumLibMissingDialog.checkAndShow("ModName") from onInitializeClient.
 */
public final class LumLibMissingDialog {

    private static final Map<String, String> TITLES = Map.ofEntries(
        Map.entry("pt", "requer LumLib para funcionar"),
        Map.entry("es", "requiere LumLib para funcionar"),
        Map.entry("fr", "nécessite LumLib pour fonctionner"),
        Map.entry("de", "benötigt LumLib zum Funktionieren"),
        Map.entry("it", "richiede LumLib per funzionare"),
        Map.entry("ja", "動作にはLumLibが必要です"),
        Map.entry("zh", "需要 LumLib 才能运行"),
        Map.entry("ko", "작동하려면 LumLib이 필요합니다"),
        Map.entry("ru", "требует LumLib для работы"),
        Map.entry("pl", "wymaga LumLib do działania"),
        Map.entry("nl", "vereist LumLib om te werken"),
        Map.entry("tr", "çalışması için LumLib gereklidir"),
        Map.entry("ar", "يتطلب LumLib للعمل"),
        Map.entry("id", "memerlukan LumLib untuk berfungsi")
    );
    private static final String TITLE_DEFAULT = "requires LumLib to work";

    private static final String BTN_DEFAULT = "Click here to download LumLib";
    private static final Map<String, String> BTNS = Map.ofEntries(
        Map.entry("pt", "Clique aqui para baixar o LumLib"),
        Map.entry("es", "Haz clic aquí para descargar LumLib"),
        Map.entry("fr", "Cliquez ici pour télécharger LumLib"),
        Map.entry("de", "Hier klicken um LumLib herunterzuladen"),
        Map.entry("ja", "ここをクリックしてLumLibをダウンロード"),
        Map.entry("zh", "点击此处下载 LumLib"),
        Map.entry("ko", "여기를 클릭하여 LumLib 다운로드"),
        Map.entry("ru", "Нажмите здесь, чтобы скачать LumLib"),
        Map.entry("pl", "Kliknij tutaj, aby pobrać LumLib"),
        Map.entry("tr", "LumLib indirmek için buraya tıklayın")
    );

    private LumLibMissingDialog() {}

    public static void checkAndShow(String modDisplayName) {
        if (FabricLoader.getInstance().isModLoaded("lumlib")) return;
        // Force AWT to initialize even when Minecraft hasn't touched it yet
        System.setProperty("java.awt.headless", "false");
        String mcVersion = FabricLoader.getInstance()
            .getModContainer("minecraft")
            .map(c -> c.getMetadata().getVersion().getFriendlyString())
            .orElse("unknown");
        try {
            // invokeAndWait so the dialog actually appears before MC continues loading;
            // also ensures the AWT EDT is started.
            SwingUtilities.invokeAndWait(() -> show(modDisplayName, mcVersion));
        } catch (Exception e) {
            // Headless or interrupted — silently skip the dialog
            org.slf4j.LoggerFactory.getLogger("armor-hud-percentages")
                .warn("[ArmorHUD] Could not show LumLib missing dialog: {}", e.toString());
        }
    }

    private static void show(String modName, String mcVersion) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        String lang = Locale.getDefault().getLanguage();
        String titleText = modName + " " + TITLES.getOrDefault(lang, TITLE_DEFAULT);
        String btnText   = BTNS.getOrDefault(lang, BTN_DEFAULT);
        String url = "https://modrinth.com/mod/lumlib/versions?g=" + mcVersion;

        Font isometra = loadFont();
        Font titleFont = isometra != null ? isometra.deriveFont(Font.BOLD, 15f)  : new Font("SansSerif", Font.BOLD, 15);
        Font bodyFont  = isometra != null ? isometra.deriveFont(Font.PLAIN, 12f) : new Font("SansSerif", Font.PLAIN, 12);
        Font btnFont   = isometra != null ? isometra.deriveFont(Font.BOLD, 13f)  : new Font("SansSerif", Font.BOLD, 13);

        JDialog dialog = new JDialog((Frame) null, true);
        dialog.setUndecorated(true);
        dialog.setSize(480, 220);
        dialog.setLocationRelativeTo(null);
        dialog.setBackground(new Color(0, 0, 0, 0));

        RoundedPanel panel = new RoundedPanel(20);
        panel.setLayout(null);

        // Title
        JLabel lbl = new JLabel("<html><center>" + titleText + "</center></html>", SwingConstants.CENTER);
        lbl.setFont(titleFont);
        lbl.setForeground(Color.WHITE);
        lbl.setBounds(20, 28, 440, 44);
        panel.add(lbl);

        // Divider decoration
        JPanel line = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                LinearGradientPaint gp = new LinearGradientPaint(0, 0, getWidth(), 0,
                        new float[]{0f, 0.5f, 1f},
                        new Color[]{new Color(92,157,245,0), new Color(92,157,245,200), new Color(92,157,245,0)});
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        line.setOpaque(false);
        line.setBounds(60, 80, 360, 1);
        panel.add(line);

        // Subtitle
        JLabel sub = new JLabel("modrinth.com/mod/lumlib  ·  mc " + mcVersion, SwingConstants.CENTER);
        sub.setFont(bodyFont);
        sub.setForeground(new Color(150, 150, 150));
        sub.setBounds(20, 90, 440, 22);
        panel.add(sub);

        // Download button
        JButton btn = new JButton(btnText) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg = getModel().isRollover()
                        ? new Color(124, 176, 247) : new Color(92, 157, 245);
                g2.setColor(bg);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                g2.setColor(new Color(255, 255, 255, 40));
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight()/2f, 12, 12));
                g2.setColor(Color.WHITE);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int tx = (getWidth() - fm.stringWidth(getText())) / 2;
                int ty = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), tx, ty);
                g2.dispose();
            }
            @Override protected void paintBorder(Graphics g) {}
        };
        btn.setFont(btnFont);
        btn.setForeground(Color.WHITE);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBounds(60, 128, 360, 38);
        btn.addActionListener(e -> {
            try { Desktop.getDesktop().browse(new URI(url)); }
            catch (Exception ex) { ex.printStackTrace(); }
        });
        panel.add(btn);

        // Close X
        JButton close = new JButton("✕") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isRollover()) {
                    g2.setColor(new Color(220, 80, 80));
                    g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 8, 8));
                }
                g2.setColor(getModel().isRollover() ? Color.WHITE : new Color(150,150,150));
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(getText(), (getWidth()-fm.stringWidth(getText()))/2, (getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
            @Override protected void paintBorder(Graphics g) {}
        };
        close.setFont(bodyFont);
        close.setContentAreaFilled(false);
        close.setBorderPainted(false);
        close.setFocusPainted(false);
        close.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        close.setBounds(444, 8, 28, 28);
        close.addActionListener(e -> dialog.dispose());
        panel.add(close);

        // Corner dots decoration
        panel.setDots(new int[][]{{30,188},{60,198},{90,194},{120,200}});

        // Drag to move
        final Point[] dragStart = {null};
        panel.addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) { dragStart[0] = e.getLocationOnScreen(); }
            @Override public void mouseReleased(MouseEvent e) { dragStart[0] = null; }
        });
        panel.addMouseMotionListener(new MouseMotionAdapter() {
            @Override public void mouseDragged(MouseEvent e) {
                if (dragStart[0] == null) return;
                Point now = e.getLocationOnScreen();
                Point loc = dialog.getLocation();
                dialog.setLocation(loc.x + now.x - dragStart[0].x, loc.y + now.y - dragStart[0].y);
                dragStart[0] = now;
            }
        });

        dialog.setContentPane(panel);
        dialog.setVisible(true);
    }

    private static Font loadFont() {
        try (InputStream is = LumLibMissingDialog.class.getResourceAsStream(
                "/assets/armor-hud-percentages/fonts/Isometra-Regular.ttf")) {
            if (is == null) return null;
            Font f = Font.createFont(Font.TRUETYPE_FONT, is);
            GraphicsEnvironment.getLocalGraphicsEnvironment().registerFont(f);
            return f;
        } catch (Exception e) {
            return null;
        }
    }

    private static class RoundedPanel extends JPanel {
        private final int arc;
        private int[][] dots = new int[0][];

        RoundedPanel(int arc) {
            super();
            this.arc = arc;
            setOpaque(false);
        }

        void setDots(int[][] dots) { this.dots = dots; }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Shadow
            g2.setColor(new Color(0, 0, 0, 80));
            g2.fill(new RoundRectangle2D.Float(4, 4, getWidth()-4, getHeight()-4, arc+4, arc+4));

            // Main bg
            g2.setColor(new Color(10, 10, 14));
            g2.fill(new RoundRectangle2D.Float(0, 0, getWidth()-4, getHeight()-4, arc, arc));

            // Border
            g2.setColor(new Color(60, 60, 70));
            g2.setStroke(new BasicStroke(1f));
            g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth()-5, getHeight()-5, arc, arc));

            // Top accent line
            LinearGradientPaint gp = new LinearGradientPaint(40, 0, getWidth()-44, 0,
                    new float[]{0f, 0.5f, 1f},
                    new Color[]{new Color(92,157,245,0), new Color(92,157,245,120), new Color(92,157,245,0)});
            g2.setPaint(gp);
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawLine(40, 1, getWidth()-44, 1);

            // Decorative dots
            for (int[] dot : dots) {
                g2.setColor(new Color(60, 60, 70));
                g2.fillOval(dot[0]-2, dot[1]-2, 4, 4);
            }

            g2.dispose();
            super.paintComponent(g);
        }
    }
}
